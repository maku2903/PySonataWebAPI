from . import (
    IFKDocumentAttachmentsController,
    IFKDocumentLinksController,
    IFKDocumentsBussinessIssueController,
    IFKDocumentsController,
    IFKDocumentsIssueController,
)
