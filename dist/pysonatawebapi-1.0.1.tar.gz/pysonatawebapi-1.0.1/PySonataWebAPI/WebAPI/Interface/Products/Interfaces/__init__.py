from . import (
    IPriceListsController,
    IProductDimensions2Controller,
    IProductDimensionsController,
    IProductPricesController,
    IProductsController,
)
