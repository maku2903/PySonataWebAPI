
class Unset:
    """Sentinel object to mark unset function parameters."""
    pass
    